#%% packages
import os
import numpy as np
from matplotlib import pyplot as plt

import chromadb
from chromadb.utils.embedding_functions import OpenCLIPEmbeddingFunction
from chromadb.utils.data_loaders import ImageLoader
import open_clip

#%% load model
# source: https://pypi.org/project/open-clip-torch-any-py3/

#%% prepare vector db

# %% add images to DB


# %% helper function to show query results

# %% Query Text

# %% Query Image

# %%
